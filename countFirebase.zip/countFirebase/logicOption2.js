// Initialize Firebase (YOUR OWN APP)
var config = {
  apiKey: "AIzaSyAo-mtNtWGIYWlqsrVNEVcjM62J8AHgAfg",
  authDomain: "https://first-project-a7163.firebaseapp.com/",
  databaseURL: "https://first-project-a7163.firebaseio.com/",
  projectId: "first-project-a7163"
}
firebase.initializeApp(config)

var database = firebase.database();
// Set Initial Counter
var initialValue = 101

var clickCounter = initialValue

// --------------------------------------------------------------

database.ref().on("value", function(snapshot) {
  clickCounter = snapshot.val().clickCounter
  $("#click-value").html(clickCounter)
}, function(err) {
  clickCounter = initialValue;
})

// --------------------------------------------------------------

// Whenever a user clicks the click button
$("#click-button").on("click", function () {

  // Reduce the clickCounter by 1
  clickCounter--;

  // Alert User and reset the counter
  if (clickCounter === 0) {

    alert("Phew! You made it! That sure was a lot of clicking.");

    clickCounter = initialValue;

  }

  // Save new value to Firebase
  database.ref().set({
    clickCounter
  })

  // Log the value of clickCounter


});

// Whenever a user clicks the restart button
$("#restart-button").on("click", function () {

  // Set the clickCounter back to initialValue
  clickCounter = initialValue;

  // Save new value to Firebase
  database.ref().set({
    clickCounter
  })

  // Log the value of clickCounter

  // Change the HTML Values
  $("#click-value").text(clickCounter);

});