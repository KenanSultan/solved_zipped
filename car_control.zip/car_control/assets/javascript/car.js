class Car {
    constructor(){
      this.make = "Honda"
      this.model = "Fit"
      this.color = "Blue Raspberry"
      this.mileage = 3000
      this.isWorking = true
    }
    driveToWork() {

      alert("Old Mileage: " + this.mileage);

      this.mileage = this.mileage + 8;

      alert("New mileage: " + this.mileage);
    }

    driveAroundWorld() {

      alert("Old Mileage: " + this.mileage);

      this.mileage = this.mileage + 24000;

      alert("New Mileage: " + this.mileage);
      alert("Car needs a tuneup!");

      this.isWorking = false;
    }

    getTuneUp() {
      alert("Car is ready to go!");
      this.isWorking = true;
    }

    honk() {
      alert("Honk! Honk!");
    }
}

let car = new Car()

  function tushu_uygula() {
    var tush = String.fromCharCode(event.keyCode).toUpperCase()

    if(tush === "A") car.driveToWork()
    else if(tush === "S") car.driveAroundWorld()
    else if(tush === "D") car.getTuneUp()
    else if(tush === "F") car.honk()
  }

  onkeypress = tushu_uygula