class yazi {
    constructor(name) {
        this.name = name
        this.status = true;

    }
    setStatus() {
        if (this.status === false) {
            this.status = true;
        } else {
            this.status = false;
        }
    }


}
class blaknot {
    constructor() {
        this.blaknot = [];
        this.active = []
        this.completed = []

    }
    addYazi(yazi) {
        this.blaknot.push(yazi)
    }
    getAll() {
        return this.blaknot
    }
    getActives() {
        for (i in this.blaknot) {
            if (this.blaknot[i][status]) {
                this.active.push(blaknot[i])
            }
        }
        return this.active
    }
    getCompleted() {
        for (i in this.blaknot) {
            if (!this.blaknot[i][status]) {
                this.completed.push(blaknot[i])
            }
        }
        return this.completed
    }
    swichCase(yazi) {
        if(yazi[status]){
            yazi[status] = false
        } else {
            yazi[status] = true
        }
    }
    remove(yazi) {
        this.blaknot.pop(yazi)
    }
}

var blaknot1 = new blaknot()



$(document).keypress(function (e) {
            switch (e.which) {
                case 13:
                let input = $(".new-todo").val()
                let yazi1 = new yazi(input)
                blaknot1.addYazi(yazi1)
                $(".new-todo").val("")
                console.log(blaknot1.getAll())
            }
        })
